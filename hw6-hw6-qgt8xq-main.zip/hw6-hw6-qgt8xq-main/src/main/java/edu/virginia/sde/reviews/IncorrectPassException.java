package edu.virginia.sde.reviews;

public class IncorrectPassException extends RuntimeException {
    public IncorrectPassException() {
        super();
    }
}
