package edu.virginia.sde.reviews;

public class CourseAlreadyReviewedException extends RuntimeException{
    public CourseAlreadyReviewedException() {
        super();
    }
}
