package edu.virginia.sde.reviews;

public class InvalidUsernameException extends RuntimeException {
    public InvalidUsernameException(){
        super();
    }
}
