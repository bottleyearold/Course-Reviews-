package edu.virginia.sde.reviews;

public class UsernameNotAvailableException extends RuntimeException{
    public UsernameNotAvailableException() {
        super();
    }
}
