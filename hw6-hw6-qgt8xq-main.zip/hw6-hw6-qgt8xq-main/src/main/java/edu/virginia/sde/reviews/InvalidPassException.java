package edu.virginia.sde.reviews;

public class InvalidPassException extends RuntimeException{
    public InvalidPassException() {
        super();
    }
}
