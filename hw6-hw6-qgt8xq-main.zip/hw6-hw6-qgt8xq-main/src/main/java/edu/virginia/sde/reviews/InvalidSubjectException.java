package edu.virginia.sde.reviews;

public class InvalidSubjectException extends RuntimeException{
    public InvalidSubjectException(){
        super();
    }
}
