package edu.virginia.sde.reviews;

public class CourseExistAlreadyException extends RuntimeException {
    public CourseExistAlreadyException() {
        super();
    }
}
