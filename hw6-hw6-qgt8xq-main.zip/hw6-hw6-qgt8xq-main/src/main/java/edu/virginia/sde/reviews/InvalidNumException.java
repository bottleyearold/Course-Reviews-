package edu.virginia.sde.reviews;

public class InvalidNumException extends RuntimeException {
    public InvalidNumException(){
        super();
    }
}
