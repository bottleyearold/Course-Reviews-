package edu.virginia.sde.reviews;

public class InvalidTitleException extends RuntimeException{
    public InvalidTitleException() {
        super();
    }
}
